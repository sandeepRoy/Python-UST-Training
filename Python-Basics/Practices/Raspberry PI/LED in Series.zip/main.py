from machine import Pin
import utime

led1 = Pin(15, Pin.OUT)
led2 = Pin(12, Pin.OUT)
led3 = Pin(14, Pin.OUT)
led4 = Pin(11, Pin.OUT)
led5 = Pin(13, Pin.OUT)
led6 = Pin(10, Pin.OUT)
while True:
  led1.toggle()
  utime.sleep(0.1)
  led2.toggle()
  utime.sleep(0.1)
  led3.toggle()
  utime.sleep(0.1)
  led4.toggle()
  utime.sleep(0.1)
  led5.toggle()
  utime.sleep(0.1)
  led6.toggle()
