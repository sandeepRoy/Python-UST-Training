from machine import Pin
import utime

led1 = Pin(15, Pin.OUT)
led2 = Pin(12, Pin.OUT)
led3 = Pin(14, Pin.OUT)
led4 = Pin(11, Pin.OUT)
led5 = Pin(13, Pin.OUT)
led6 = Pin(10, Pin.OUT)
led7 = Pin(9, Pin.OUT)
led8 = Pin(8, Pin.OUT)
led9 = Pin(7, Pin.OUT)  

def showNumber(number):
  if(number == 1):
    #led1.toggle()
    #led2.toggle()
    led3.toggle()
    #led4.toggle()
    #led5.toggle()
    led6.toggle()
    #led7.toggle()
    #led8.toggle()
    led9.toggle()
  elif(number == 0):
    led1.toggle()
    led2.toggle()
    led3.toggle()
    led4.toggle()
    #led5.toggle()
    led6.toggle()
    led7.toggle()
    led8.toggle()
    led9.toggle()

number = input()
showNumber(number)
